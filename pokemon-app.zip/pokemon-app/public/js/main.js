document.getElementById('buscador-pokemon-form').addEventListener('submit', async (event) => {
    event.preventDefault(); // Impede o comportamento padrão do formulário
  
    // Pega o valor do input e converte para minúsculas (a PokeAPI trabalha com nomes em minúsculo)
    const pokemonName = document.getElementById('pokemon-name').value.trim().toLowerCase();
    
    if (!pokemonName) return;
  
    const url = `https://pokeapi.co/api/v2/pokemon/${pokemonName}`;
  
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error('Pokémon não encontrado!');
      }
      
      const pokemon = await response.json();
      displayPokemon(pokemon);
    } catch (error) {
      document.getElementById('pokemon-data').innerHTML = `<p>${error.message}</p>`;
    }
  });
  
  function displayPokemon(pokemon) {
    const container = document.getElementById('pokemon-data');
    
    // Cria o HTML com alguns dados do Pokémon
    container.innerHTML = `
      <h2>${pokemon.name.toUpperCase()}</h2>
      <img src="${pokemon.sprites.front_default}" alt="${pokemon.name}">
      <p><strong>Altura:</strong> ${pokemon.height}</p>
      <p><strong>Peso:</strong> ${pokemon.weight}</p>
      <p><strong>Tipo(s):</strong> ${pokemon.types.map(t => t.type.name).join(', ')}</p>
    `;
  }
  